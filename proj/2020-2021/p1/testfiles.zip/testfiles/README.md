# Compiling randomDAG.cpp

g++ -O3 -Wall -o randomDAG randomDAG.cpp -lm
